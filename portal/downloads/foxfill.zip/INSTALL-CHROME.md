# Install in Google Chrome

## Option A — Chrome Web Store (recommended when listed)
Open the extension's Web Store page and click Add to Chrome.

## Option B — Load this zip
1. Unzip this folder somewhere permanent (do not delete it later).
2. Open Chrome → chrome://extensions
3. Turn on Developer mode (top right).
4. Click Load unpacked → select the unzipped folder (contains manifest.json).
5. Pin from the puzzle icon if you like.

To update: download a new zip, replace the folder contents, Reload on chrome://extensions.