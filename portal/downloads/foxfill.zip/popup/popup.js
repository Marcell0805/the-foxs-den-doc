/**
 * FoxFill popup — Phase 8b: multi-profile, custom fields, encryption at rest.
 */

const scanBtn = document.getElementById("scanBtn");
const fillBtn = document.getElementById("fillBtn");
const statusEl = document.getElementById("status");
const summaryEl = document.getElementById("summary");
const errorEl = document.getElementById("error");
const reviewEl = document.getElementById("review");
const emptyStateEl = document.getElementById("emptyState");
const profileNudgeEl = document.getElementById("profileNudge");
const nudgePersonalBtn = document.getElementById("nudgePersonal");
const profileSelect = document.getElementById("profileSelect");
const profileNewBtn = document.getElementById("profileNewBtn");
const profileRenameBtn = document.getElementById("profileRenameBtn");
const profileDeleteBtn = document.getElementById("profileDeleteBtn");
const listWill = document.getElementById("listWill");
const listReview = document.getElementById("listReview");
const listUnmatched = document.getElementById("listUnmatched");
const countWill = document.getElementById("countWill");
const countReview = document.getElementById("countReview");
const countUnmatched = document.getElementById("countUnmatched");
const toggleUnmatched = document.getElementById("toggleUnmatched");
const personalForm = document.getElementById("personalForm");
const addressForm = document.getElementById("addressForm");
const personalSaveMsg = document.getElementById("personalSaveMsg");
const addressSaveMsg = document.getElementById("addressSaveMsg");
const unlockGate = document.getElementById("unlockGate");
const unlockPassphrase = document.getElementById("unlockPassphrase");
const unlockBtn = document.getElementById("unlockBtn");
const unlockError = document.getElementById("unlockError");
const unlockRecoveryEmail = document.getElementById("unlockRecoveryEmail");
const recoverBtn = document.getElementById("recoverBtn");
const resetVaultBtn = document.getElementById("resetVaultBtn");
const customFieldList = document.getElementById("customFieldList");
const customFieldForm = document.getElementById("customFieldForm");
const customSaveMsg = document.getElementById("customSaveMsg");
const encryptionStatus = document.getElementById("encryptionStatus");
const encryptionOffControls = document.getElementById("encryptionOffControls");
const encryptionOnControls = document.getElementById("encryptionOnControls");
const enablePassphrase = document.getElementById("enablePassphrase");
const enablePassphrase2 = document.getElementById("enablePassphrase2");
const enableRecoveryEmail = document.getElementById("enableRecoveryEmail");
const enableEncryptionBtn = document.getElementById("enableEncryptionBtn");
const disableEncryptionBtn = document.getElementById("disableEncryptionBtn");
const lockNowBtn = document.getElementById("lockNowBtn");
const encryptionError = document.getElementById("encryptionError");
const openSettingsBtn = document.getElementById("openSettingsBtn");
const openSettingsFooterBtn = document.getElementById("openSettingsFooterBtn");
const openSettingsFromPersonal = document.getElementById(
  "openSettingsFromPersonal"
);

const PROFILE_KEYS = [
  "title",
  "firstName",
  "lastName",
  "idNumber",
  "passportNumber",
  "email",
  "phone",
  "dateOfBirth",
  "residenceType",
  "addressLine1",
  "addressLine2",
  "suburb",
  "city",
  "province",
  "postalCode",
  "country",
];

const RESTRICTED_PREFIXES = [
  "chrome://",
  "chrome-extension://",
  "edge://",
  "about:",
  "devtools://",
  "https://chrome.google.com/webstore",
  "https://chromewebstore.google.com",
];

/** @type {Record<string, string>} */
let profile = emptyProfile();

/** @type {Array<{id:string,label:string,aliases:string[],value:string}>} */
let customFields = [];

/** @type {object|null} */
let profileStore = null;

/** @type {boolean} */
let vaultLocked = false;

/** @type {object[]|null} */
let lastMatches = null;

/** @type {number|null} */
let lastTabId = null;

/** @type {Set<number>} */
let selectedIndexes = new Set();

function emptyProfile() {
  return Object.fromEntries(PROFILE_KEYS.map((key) => [key, ""]));
}

function activeProfileName() {
  const active = FoxFillProfiles?.getActive?.(profileStore);
  return active?.name || "Personal";
}

function setError(message) {
  errorEl.hidden = !message;
  errorEl.textContent = message || "";
}

function setStatus(message, kind) {
  statusEl.textContent = message;
  statusEl.classList.remove("is-success", "is-empty", "is-error");
  if (kind) statusEl.classList.add(kind);
}

function profileFilledCount() {
  const builtIn = PROFILE_KEYS.filter((key) =>
    String(profile[key] || "").trim()
  ).length;
  const custom = customFields.filter((cf) => String(cf.value || "").trim())
    .length;
  return builtIn + custom;
}

function isProfileThin() {
  return profileFilledCount() < 2;
}

function showEmptyState(show, title, body) {
  if (!emptyStateEl) return;
  emptyStateEl.hidden = !show;
  if (show) {
    const titleEl = emptyStateEl.querySelector(".empty-title");
    const bodyEl = emptyStateEl.querySelector(".empty-body");
    if (titleEl) {
      titleEl.textContent = title || "Ready when you are";
    }
    if (bodyEl) {
      bodyEl.textContent =
        body ||
        "Pick a profile above, save Personal and Address details, open a form page, then hit Scan Form.";
    }
  }
}

function updateProfileNudge() {
  if (!profileNudgeEl) return;
  profileNudgeEl.hidden = !isProfileThin() || !lastMatches;
}

function restrictedPageMessage(url) {
  const u = String(url || "");
  if (u.startsWith("chrome://") || u.startsWith("edge://") || u.startsWith("about:")) {
    return "This is a browser page. Open a normal website with a form, then scan.";
  }
  if (u.startsWith("chrome-extension://") || u.startsWith("devtools://")) {
    return "FoxFill can’t scan extension or DevTools pages.";
  }
  if (
    u.startsWith("https://chrome.google.com/webstore") ||
    u.startsWith("https://chromewebstore.google.com")
  ) {
    return "Chrome Web Store pages can’t be scanned. Open your form site instead.";
  }
  if (u.startsWith("file:")) {
    return "Local files sometimes block scripts. If scan fails, host the page or use a normal http(s) site.";
  }
  return "FoxFill can’t scan this page. Open a normal website and try again.";
}

function activateTab(id) {
  const tabs = document.querySelectorAll(".tab");
  const panels = document.querySelectorAll(".panel");
  tabs.forEach((t) => {
    const active = t.dataset.tab === id;
    t.classList.toggle("is-active", active);
    t.setAttribute("aria-selected", active ? "true" : "false");
  });
  panels.forEach((panel) => {
    const active = panel.dataset.panel === id;
    panel.classList.toggle("is-active", active);
    panel.hidden = !active;
  });
}

function isRestrictedUrl(url) {
  if (!url) return true;
  return RESTRICTED_PREFIXES.some((prefix) => url.startsWith(prefix));
}

function isWillFill(match) {
  return match.status === "will_fill" || match.status === "matched";
}

function resolvedFillValue(match) {
  if (match.fillValue != null && String(match.fillValue).trim() !== "") {
    return String(match.fillValue).trim();
  }
  if (match.profileKey === "phoneCountryCode") return "";
  if (match.profileKey && String(match.profileKey).startsWith("custom:")) {
    const id = String(match.profileKey).slice("custom:".length);
    const cf = customFields.find((item) => item.id === id);
    return cf ? String(cf.value || "").trim() : "";
  }
  if (match.profileKey && profile[match.profileKey]) {
    return String(profile[match.profileKey] || "").trim();
  }
  return "";
}

function canInclude(match) {
  return Boolean(resolvedFillValue(match));
}

function selectedFillable() {
  return (lastMatches || []).filter(
    (m) => selectedIndexes.has(m.index) && canInclude(m)
  );
}

function updateFillButton() {
  const fillable = selectedFillable();
  const count = fillable.length;
  if (count === 0) {
    fillBtn.hidden = true;
    fillBtn.disabled = true;
    fillBtn.classList.remove("is-ready");
    fillBtn.textContent = "Fill Fields";
    return;
  }
  fillBtn.hidden = false;
  fillBtn.disabled = false;
  fillBtn.classList.add("is-ready");
  fillBtn.textContent = `Fill ${count} Field${count === 1 ? "" : "s"}`;
}

function updateSummary(matches) {
  const will = matches.filter((m) => isWillFill(m)).length;
  const review = matches.filter((m) => m.status === "needs_review").length;
  const unmatched = matches.filter(
    (m) => !isWillFill(m) && m.status !== "needs_review"
  ).length;
  const selected = selectedFillable().length;

  summaryEl.hidden = false;
  summaryEl.innerHTML = "";

  const chips = [
    { label: `${will} ready`, className: "chip-ready" },
    { label: `${review} review`, className: "chip-review" },
    { label: `${unmatched} unmatched`, className: "chip-none" },
    { label: `${selected} selected`, className: "chip-selected" },
  ];

  for (const chip of chips) {
    const span = document.createElement("span");
    span.className = `chip ${chip.className}`;
    span.textContent = chip.label;
    summaryEl.append(span);
  }
}

function displayTitle(match) {
  if (match.profileKey === "dateOfBirth" && match.dobPart) {
    if (match.dobPart === "day") return "Birth day";
    if (match.dobPart === "month") return "Birth month";
    if (match.dobPart === "year") return "Birth year";
  }
  const fp = match.fingerprint || {};
  const clue = stripStatusMarks(primaryClue(fp));
  // Prefer profile field name over example placeholders once matched.
  if (
    match.profileLabel &&
    (/^(e\.?g\.?|example|sample)\b/i.test(clue) || clue === "(no clues)")
  ) {
    return match.profileLabel;
  }
  return clue || match.profileLabel || "(no clues)";
}

function stripStatusMarks(text) {
  return String(text || "")
    .replace(/[\u{1F7E0}-\u{1F7EB}\u{26AA}\u{26AB}]/gu, "")
    .replace(/\s+/g, " ")
    .trim();
}

function primaryClue(field) {
  const isDialPrefix = (text) => {
    const raw = String(text || "").trim();
    if (!raw || raw.length > 16) return false;
    return /^\+\d{1,4}$/.test(raw) || (/^\+?\d{1,4}$/.test(raw) && raw.length <= 5);
  };
  const candidates = [
    field.label,
    field.ariaLabel,
    field.placeholder,
    field.name,
    field.id,
    field.autocomplete,
  ].filter(Boolean);
  const preferred = candidates.find((c) => !isDialPrefix(c));
  return preferred || candidates[0] || "(no clues)";
}

function statusMeta(match) {
  const fillVal = resolvedFillValue(match);
  const compoundBit =
    match.compound?.type === "phone"
      ? match.compound.role === "dial"
        ? " · dial companion"
        : match.fillMode === "phone_national"
          ? " · national"
          : match.fillMode === "phone_full"
            ? " · full"
            : ""
      : "";

  if (isWillFill(match)) {
    const label = match.profileLabel || match.profileKey || "Profile";
    const fitBit = match.fitted
      ? match.fingerprint?.maxLength != null
        ? ` · fits maxlen ${match.fingerprint.maxLength}`
        : " · fitted"
      : "";
    return {
      pill: "Will fill",
      pillClass: "pill-matched",
      detail: `${label}${compoundBit}${fitBit}`,
      fillValue: match.fillLabel || fillVal || "(empty in profile)",
    };
  }
  if (match.status === "needs_review") {
    const keyBit = match.profileLabel || match.profileKey || "Possible match";
    const reason = match.reason || "Needs review";
    const shortReason =
      reason.length > 72 ? `${reason.slice(0, 69)}…` : reason;
    return {
      pill: "Check",
      pillClass: "pill-review",
      detail: `${keyBit} · ${shortReason}`,
      fillValue: match.fillLabel || fillVal || "",
    };
  }
  return {
    pill: "Not matched",
    pillClass: "pill-none",
    detail: match.reason || "No confident match",
    fillValue: "",
  };
}

function createFieldItem(match, options) {
  const { selectable, checked, disabled } = options;
  const meta = statusMeta(match);

  const li = document.createElement("li");
  li.className = "field-item";
  if (disabled) li.classList.add("is-disabled");

  const top = document.createElement("div");
  top.className = "field-top";

  if (selectable) {
    const label = document.createElement("label");
    label.className = "field-select";

    const input = document.createElement("input");
    input.type = "checkbox";
    input.checked = Boolean(checked);
    input.disabled = Boolean(disabled);
    input.dataset.index = String(match.index);
    input.setAttribute(
      "aria-label",
      `Include ${displayTitle(match)} when filling`
    );
    input.addEventListener("change", () => {
      if (input.checked) selectedIndexes.add(match.index);
      else selectedIndexes.delete(match.index);
      updateFillButton();
      if (lastMatches) updateSummary(lastMatches);
    });

    const title = document.createElement("span");
    title.className = "field-title";
    title.textContent = displayTitle(match);

    label.append(input, title);
    top.append(label);
  } else {
    const title = document.createElement("span");
    title.className = "field-title";
    title.textContent = displayTitle(match);
    top.append(title);
  }

  const pill = document.createElement("span");
  pill.className = `pill ${meta.pillClass}`;
  pill.textContent = meta.pill;
  top.append(pill);

  const detail = document.createElement("div");
  detail.className = "field-meta";
  detail.textContent = meta.detail;

  li.append(top, detail);

  if (meta.fillValue) {
    const valueEl = document.createElement("div");
    valueEl.className = "field-value";
    valueEl.textContent = meta.fillValue;
    valueEl.title = meta.fillValue;
    li.append(valueEl);
  }

  return li;
}

function resetUnmatchedCollapse() {
  listUnmatched.hidden = true;
  listUnmatched.classList.add("is-collapsed");
  toggleUnmatched.setAttribute("aria-expanded", "false");
}

function renderMatches(matches) {
  listWill.innerHTML = "";
  listReview.innerHTML = "";
  listUnmatched.innerHTML = "";

  const will = [];
  const review = [];
  const unmatched = [];

  for (const match of matches) {
    if (isWillFill(match)) will.push(match);
    else if (match.status === "needs_review") review.push(match);
    else unmatched.push(match);
  }

  selectedIndexes = new Set(
    will.filter((m) => canInclude(m)).map((m) => m.index)
  );

  for (const match of will) {
    const includable = canInclude(match);
    listWill.append(
      createFieldItem(match, {
        selectable: true,
        checked: includable,
        disabled: !includable,
      })
    );
  }

  for (const match of review) {
    const includable = canInclude(match);
    listReview.append(
      createFieldItem(match, {
        selectable: includable,
        checked: false,
        disabled: !includable,
      })
    );
  }

  for (const match of unmatched) {
    listUnmatched.append(
      createFieldItem(match, {
        selectable: false,
        checked: false,
        disabled: false,
      })
    );
  }

  countWill.textContent = String(will.length);
  countReview.textContent = String(review.length);
  countUnmatched.textContent = String(unmatched.length);

  const groupWill = reviewEl.querySelector('[data-group="will_fill"]');
  const groupReview = reviewEl.querySelector('[data-group="needs_review"]');
  const groupUnmatched = reviewEl.querySelector('[data-group="unmatched"]');

  groupWill.hidden = will.length === 0;
  groupReview.hidden = review.length === 0;
  groupUnmatched.hidden = unmatched.length === 0;

  reviewEl.hidden = matches.length === 0;
  resetUnmatchedCollapse();
  updateSummary(matches);
  updateFillButton();
  updateProfileNudge();
  showEmptyState(false);
}

function clearReview() {
  reviewEl.hidden = true;
  summaryEl.hidden = true;
  summaryEl.innerHTML = "";
  listWill.innerHTML = "";
  listReview.innerHTML = "";
  listUnmatched.innerHTML = "";
  selectedIndexes = new Set();
  updateFillButton();
  updateProfileNudge();
}

/**
 * Prototype in-page overlay: outline fields + floating summary panel.
 */
async function showPageOverlay(matches, tabId) {
  try {
    const byFrame = new Map();
    for (const m of matches || []) {
      const fid = m.frameId ?? 0;
      if (!byFrame.has(fid)) byFrame.set(fid, []);
      byFrame.get(fid).push({
        status: m.status,
        profileLabel: m.profileLabel || m.profileKey || "",
        label: displayTitle(m),
        fill: resolvedFillValue(m),
        fingerprint: m.fingerprint,
      });
    }

    for (const [frameId, frameMatches] of byFrame) {
      await chrome.scripting.executeScript({
        target: { tabId, frameIds: [frameId] },
        files: ["content/overlay.js"],
      });
      await chrome.scripting.executeScript({
        target: { tabId, frameIds: [frameId] },
        func: (payload) => {
          if (typeof globalThis.FoxFillShowOverlay === "function") {
            return globalThis.FoxFillShowOverlay(payload);
          }
          return { ok: false };
        },
        args: [{ matches: frameMatches }],
      });
    }
  } catch (err) {
    console.warn("[FoxFill] Overlay preview failed:", err);
  }
}

function normalizeDob(value) {
  if (!value) return "";
  if (typeof FoxFillDateFormat !== "undefined" && FoxFillDateFormat.toIso) {
    return FoxFillDateFormat.toIso(value) || "";
  }
  return String(value).trim();
}

const dobHidden = document.getElementById("dateOfBirth");
const dobDayBtn = document.getElementById("dobDayBtn");
const dobMonthBtn = document.getElementById("dobMonthBtn");
const dobYearBtn = document.getElementById("dobYearBtn");
const dobDayMenu = document.getElementById("dobDayMenu");
const dobMonthMenu = document.getElementById("dobMonthMenu");
const dobYearMenu = document.getElementById("dobYearMenu");
const phoneInput = document.getElementById("phoneInput");
const countryInput = document.getElementById("countryInput");
const countryBtn = document.getElementById("countryBtn");
const countryMenu = document.getElementById("countryMenu");
const countryDd = document.getElementById("countryDd");
const provinceFieldLabel = document.getElementById("provinceFieldLabel");
const postalCodeFieldLabel = document.getElementById("postalCodeFieldLabel");

const MONTHS = [
  ["01", "January"],
  ["02", "February"],
  ["03", "March"],
  ["04", "April"],
  ["05", "May"],
  ["06", "June"],
  ["07", "July"],
  ["08", "August"],
  ["09", "September"],
  ["10", "October"],
  ["11", "November"],
  ["12", "December"],
];

const dobState = { day: "", month: "", year: "" };

function daysInMonth(year, month) {
  const y = Number(year);
  const m = Number(month);
  if (!y || !m) return 31;
  return new Date(y, m, 0).getDate();
}

function setDobButtonLabel(btn, value, placeholder) {
  const label = btn.querySelector(".dob-dd-label");
  label.textContent = value || placeholder;
  label.classList.toggle("is-placeholder", !value);
}

function closeAllDobMenus() {
  for (const root of document.querySelectorAll(".dob-dd")) {
    root.classList.remove("is-open");
    const btn = root.querySelector(".dob-dd-btn");
    const menu = root.querySelector(".dob-dd-menu");
    if (btn) btn.setAttribute("aria-expanded", "false");
    if (menu) menu.hidden = true;
  }
}

function openDobMenu(root) {
  closeAllDobMenus();
  const btn = root.querySelector(".dob-dd-btn");
  const menu = root.querySelector(".dob-dd-menu");
  root.classList.add("is-open");
  btn.setAttribute("aria-expanded", "true");
  menu.hidden = false;
  const filter = menu.querySelector(".dob-dd-filter");
  if (filter) {
    filter.value = "";
    filter.dispatchEvent(new Event("input", { bubbles: false }));
    queueMicrotask(() => filter.focus());
    return;
  }
  const active = menu.querySelector(".is-active");
  if (active) active.scrollIntoView({ block: "nearest" });
}

function dobFilterMatch(text, value, query) {
  const q = String(query || "")
    .trim()
    .toLowerCase();
  if (!q) return true;
  const label = String(text || "").toLowerCase();
  const raw = String(value || "").toLowerCase();
  const bare = raw.replace(/^0+/, "") || raw;
  const qBare = q.replace(/^0+/, "") || q;
  return (
    label.startsWith(q) ||
    label.includes(q) ||
    raw.startsWith(q) ||
    bare.startsWith(qBare) ||
    bare === qBare
  );
}

function fillDobMenu(menu, items, selected, onPick) {
  menu.innerHTML = "";

  const filterLi = document.createElement("li");
  filterLi.className = "dob-dd-filter-row";
  const filter = document.createElement("input");
  filter.type = "search";
  filter.className = "dob-dd-filter";
  filter.placeholder = "Type to filter…";
  filter.setAttribute("autocomplete", "off");
  filter.setAttribute("aria-label", "Filter options");
  filterLi.append(filter);
  menu.append(filterLi);

  const optionsHost = document.createElement("li");
  optionsHost.className = "dob-dd-options-host";
  const optionsList = document.createElement("ul");
  optionsList.className = "dob-dd-options";
  optionsHost.append(optionsList);
  menu.append(optionsHost);

  function renderOptions(query) {
    optionsList.innerHTML = "";
    const q = String(query || "").trim();
    let shown = 0;
    for (const [value, text] of items) {
      if (!value && q) continue;
      if (value && !dobFilterMatch(text, value, q)) continue;
      const li = document.createElement("li");
      const opt = document.createElement("button");
      opt.type = "button";
      opt.className = "dob-dd-option";
      opt.setAttribute("role", "option");
      opt.dataset.value = value;
      opt.textContent = text;
      if (value && value === selected) opt.classList.add("is-active");
      opt.addEventListener("click", (event) => {
        event.preventDefault();
        onPick(value, text);
        closeAllDobMenus();
      });
      li.append(opt);
      optionsList.append(li);
      shown += 1;
    }
    if (!shown) {
      const empty = document.createElement("li");
      empty.className = "dob-dd-empty";
      empty.textContent = "No matches";
      optionsList.append(empty);
    }
    const active = optionsList.querySelector(".is-active");
    if (active) active.scrollIntoView({ block: "nearest" });
  }

  filter.addEventListener("input", () => renderOptions(filter.value));
  filter.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      event.preventDefault();
      const first = optionsList.querySelector(".dob-dd-option");
      if (first) first.click();
    } else if (event.key === "Escape") {
      event.preventDefault();
      closeAllDobMenus();
    }
  });
  filter.addEventListener("click", (event) => event.stopPropagation());

  renderOptions("");
}

function rebuildDobDayMenu() {
  const max = daysInMonth(dobState.year, dobState.month);
  if (dobState.day && Number(dobState.day) > max) {
    dobState.day = "";
  }
  const items = [["", "Day"]];
  for (let d = 1; d <= max; d += 1) {
    const v = String(d).padStart(2, "0");
    items.push([v, String(d)]);
  }
  fillDobMenu(dobDayMenu, items, dobState.day, (value, text) => {
    dobState.day = value;
    setDobButtonLabel(dobDayBtn, value ? text : "", "Day");
    syncDobHiddenFromSelects();
  });
  setDobButtonLabel(
    dobDayBtn,
    dobState.day ? String(Number(dobState.day)) : "",
    "Day"
  );
}

function rebuildDobMonthMenu() {
  const items = [["", "Month"], ...MONTHS];
  fillDobMenu(dobMonthMenu, items, dobState.month, (value, text) => {
    dobState.month = value;
    setDobButtonLabel(dobMonthBtn, value ? text : "", "Month");
    rebuildDobDayMenu();
    syncDobHiddenFromSelects();
  });
  const monthLabel = MONTHS.find(([v]) => v === dobState.month)?.[1] || "";
  setDobButtonLabel(dobMonthBtn, monthLabel, "Month");
}

function rebuildDobYearMenu() {
  const thisYear = new Date().getFullYear();
  const items = [["", "Year"]];
  for (let y = thisYear; y >= 1920; y -= 1) {
    items.push([String(y), String(y)]);
  }
  fillDobMenu(dobYearMenu, items, dobState.year, (value, text) => {
    dobState.year = value;
    setDobButtonLabel(dobYearBtn, value ? text : "", "Year");
    rebuildDobDayMenu();
    syncDobHiddenFromSelects();
  });
  setDobButtonLabel(dobYearBtn, dobState.year, "Year");
}

function syncDobHiddenFromSelects() {
  const { year: y, month: m, day: d } = dobState;
  dobHidden.value = y && m && d ? `${y}-${m}-${d}` : "";
}

function setDobSelectsFromIso(iso) {
  const value = normalizeDob(iso);
  if (!value || !/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    dobState.year = "";
    dobState.month = "";
    dobState.day = "";
    rebuildDobYearMenu();
    rebuildDobMonthMenu();
    rebuildDobDayMenu();
    dobHidden.value = "";
    return;
  }
  const [y, m, d] = value.split("-");
  dobState.year = y;
  dobState.month = m;
  dobState.day = d;
  rebuildDobYearMenu();
  rebuildDobMonthMenu();
  rebuildDobDayMenu();
  syncDobHiddenFromSelects();
}

function populateDobSelects() {
  rebuildDobYearMenu();
  rebuildDobMonthMenu();
  rebuildDobDayMenu();

  const map = [
    [dobDayBtn, dobDayMenu],
    [dobMonthBtn, dobMonthMenu],
    [dobYearBtn, dobYearMenu],
  ];
  for (const [btn, menu] of map) {
    btn.addEventListener("click", (event) => {
      event.preventDefault();
      const root = btn.closest(".dob-dd");
      const open = root.classList.contains("is-open");
      if (open) closeAllDobMenus();
      else openDobMenu(root);
    });
  }

  document.addEventListener("click", (event) => {
    if (!event.target.closest(".dob-dd")) closeAllDobMenus();
  });
}

function guessDefaultCountry() {
  const lang =
    (typeof chrome !== "undefined" && chrome.i18n?.getUILanguage?.()) ||
    (typeof navigator !== "undefined" && navigator.language) ||
    "";
  return (
    globalThis.FoxFillCountries?.guessCountryFromLocale?.(lang) ||
    "United States"
  );
}

function isProfileBlank(data) {
  return PROFILE_KEYS.every((key) => !String(data?.[key] || "").trim());
}

function seedCountryIfNeeded(data) {
  if (!data || String(data.country || "").trim()) return false;
  if (!isProfileBlank(data)) return false;
  data.country = guessDefaultCountry();
  return true;
}

function updatePhonePlaceholder(countryName) {
  if (!phoneInput) return;
  phoneInput.placeholder =
    globalThis.FoxFillCountries?.phonePlaceholderForCountry?.(countryName) ||
    "+…";
}

function updateAddressLabels(countryName) {
  const labels =
    globalThis.FoxFillCountries?.addressLabelsForCountry?.(countryName) || {
      province: "Province",
      postalCode: "Postal Code",
    };
  if (provinceFieldLabel) provinceFieldLabel.textContent = labels.province;
  if (postalCodeFieldLabel) {
    postalCodeFieldLabel.textContent = labels.postalCode;
  }
}

function setCountryUi(countryName) {
  const value = String(countryName || "").trim();
  if (countryInput) countryInput.value = value;
  if (countryBtn) {
    setDobButtonLabel(countryBtn, value, "Select country…");
  }
  updatePhonePlaceholder(value);
  updateAddressLabels(value);
}

function rebuildCountryMenu() {
  if (!countryMenu) return;
  const countries = globalThis.FoxFillCountries?.listCountries?.() || [];
  const items = [["", "Select country…"]];
  for (const c of countries) {
    items.push([c.name, c.name]);
  }
  const selected = String(countryInput?.value || "").trim();
  fillDobMenu(countryMenu, items, selected, (value) => {
    setCountryUi(value);
    profile.country = value;
  });
  setCountryUi(selected);
}

function populateCountrySelect() {
  if (!countryBtn || !countryMenu || !countryDd) return;
  rebuildCountryMenu();
  countryBtn.addEventListener("click", (event) => {
    event.preventDefault();
    const open = countryDd.classList.contains("is-open");
    if (open) closeAllDobMenus();
    else {
      rebuildCountryMenu();
      openDobMenu(countryDd);
    }
  });
}

function fillFormsFromProfile() {
  for (const form of [personalForm, addressForm]) {
    for (const el of form.elements) {
      if (!el.name || !PROFILE_KEYS.includes(el.name)) continue;
      if (el.name === "dateOfBirth") continue;
      if (el.name === "country") continue;
      el.value = profile[el.name] || "";
    }
  }
  setDobSelectsFromIso(profile.dateOfBirth || "");
  setCountryUi(profile.country || "");
  rebuildCountryMenu();
}

function readFormIntoProfile(form) {
  if (form === personalForm) {
    syncDobHiddenFromSelects();
  }
  for (const el of form.elements) {
    if (el.name && PROFILE_KEYS.includes(el.name)) {
      let value = String(el.value || "").trim();
      if (el.name === "dateOfBirth") value = normalizeDob(value);
      profile[el.name] = value;
    }
  }
}

populateDobSelects();
populateCountrySelect();

async function loadProfile() {
  // Never show the lock gate unless encryption is actually on and locked.
  setLockedUi(false);
  vaultLocked = false;

  if (typeof FoxFillProfiles === "undefined") {
    profile = emptyProfile();
    customFields = [];
    return;
  }

  try {
    const peek = await FoxFillProfiles.peekEncryption();
    if (!peek.encrypted) {
      profileStore = await FoxFillProfiles.loadStore(PROFILE_KEYS);
      vaultLocked = false;
      setLockedUi(false);
      applyActiveProfileToUi();
      renderProfileSelect();
      renderCustomFields();
      updateEncryptionUi();
      return;
    }

    // Encrypted at rest — try this browser session first (no re-prompt).
    profileStore = await FoxFillProfiles.loadStore(PROFILE_KEYS);
    vaultLocked = false;
    setLockedUi(false);
    applyActiveProfileToUi();
    renderProfileSelect();
    renderCustomFields();
    updateEncryptionUi();
  } catch (err) {
    if (err?.code === "LOCKED") {
      vaultLocked = true;
      setLockedUi(true);
      if (unlockPassphrase) unlockPassphrase.value = "";
      return;
    }
    console.error("FoxFill load error:", err);
    setError("Couldn’t load profiles from local storage.");
    setLockedUi(false);
  }
}

function setLockedUi(locked) {
  document.body.classList.toggle("is-locked", Boolean(locked));
  if (unlockGate) {
    unlockGate.hidden = !locked;
  }
  if (!locked && unlockError) {
    unlockError.hidden = true;
    unlockError.textContent = "";
  }
}

function renderProfileSelect() {
  if (!profileSelect || !profileStore || typeof FoxFillProfiles === "undefined") {
    return;
  }
  const list = FoxFillProfiles.listProfiles(profileStore);
  const activeId = profileStore.activeProfileId;
  profileSelect.innerHTML = "";
  for (const p of list) {
    const opt = document.createElement("option");
    opt.value = p.id;
    opt.textContent = p.name;
    if (p.id === activeId) opt.selected = true;
    profileSelect.append(opt);
  }
  if (profileDeleteBtn) {
    profileDeleteBtn.disabled = list.length <= 1;
  }
}

function refreshMatchesForActiveProfile() {
  if (!lastMatches) return;
  const byFrame = new Map();
  for (const m of lastMatches) {
    const fid = m.frameId ?? 0;
    if (!byFrame.has(fid)) byFrame.set(fid, []);
    byFrame.get(fid).push(m);
  }
  const rebuilt = [];
  let globalIndex = 0;
  for (const [frameId, raw] of byFrame) {
    let local = raw.map((m, i) => ({
      ...m,
      index: i,
      frameId,
      compound: undefined,
      fillMode: undefined,
      fillValue:
        m.profileKey === "phone" || String(m.profileKey || "").startsWith("custom:")
          ? undefined
          : m.fillValue,
    }));
    if (typeof FoxFillApplyPhoneCompounds === "function") {
      local = FoxFillApplyPhoneCompounds(local, {
        phone: profile.phone || "",
        country: profile.country || "",
        dateOfBirth: profile.dateOfBirth || "",
      });
    }
    const localToGlobal = new Map();
    for (const m of local) {
      localToGlobal.set(m.index, globalIndex);
      rebuilt.push({
        ...m,
        index: globalIndex,
        frameId,
        localIndex: m.index,
      });
      globalIndex += 1;
    }
    for (const m of rebuilt) {
      if (m.frameId !== frameId) continue;
      if (m.compound && m.compound.pairedIndex != null) {
        const mapped = localToGlobal.get(m.compound.pairedIndex);
        if (mapped != null) {
          m.compound = { ...m.compound, pairedIndex: mapped };
        }
      }
    }
  }
  lastMatches = rebuilt;
  renderMatches(lastMatches);
}

function applyActiveProfileToUi() {
  const active = FoxFillProfiles.getActive(profileStore);
  profile = { ...emptyProfile(), ...(active?.data || {}) };
  customFields = FoxFillProfiles.normalizeCustomFields(
    active?.customFields || []
  );
  const seeded = seedCountryIfNeeded(profile);
  fillFormsFromProfile();
  renderCustomFields();
  updateProfileNudge();
  updateEncryptionUi();
  refreshMatchesForActiveProfile();
  if (seeded) {
    syncActiveIntoStore();
    void persistStore();
  }
}

async function persistStore() {
  if (!profileStore || typeof FoxFillProfiles === "undefined") return;
  await FoxFillProfiles.saveStore(profileStore);
}

function syncActiveIntoStore() {
  if (!profileStore || typeof FoxFillProfiles === "undefined") return;
  FoxFillProfiles.upsertActiveData(
    profileStore,
    profile,
    PROFILE_KEYS,
    customFields
  );
}

async function saveProfile(fromForm, msgEl) {
  readFormIntoProfile(fromForm);
  readFormIntoProfile(
    fromForm === personalForm ? addressForm : personalForm
  );
  syncActiveIntoStore();
  await persistStore();
  msgEl.hidden = false;
  window.setTimeout(() => {
    msgEl.hidden = true;
  }, 1600);
  updateProfileNudge();
  refreshMatchesForActiveProfile();
}

async function switchProfile(profileId) {
  if (!profileStore || typeof FoxFillProfiles === "undefined") return;
  readFormIntoProfile(personalForm);
  readFormIntoProfile(addressForm);
  syncActiveIntoStore();
  FoxFillProfiles.setActive(profileStore, profileId);
  await persistStore();
  applyActiveProfileToUi();
  renderProfileSelect();
  setStatus(`Switched to “${activeProfileName()}”.`, "is-success");
}

async function createProfile() {
  if (!profileStore || typeof FoxFillProfiles === "undefined") return;
  const name = window.prompt("Name for the new profile", "Work");
  if (name == null) return;
  const trimmed = String(name).trim();
  if (!trimmed) return;

  readFormIntoProfile(personalForm);
  readFormIntoProfile(addressForm);
  syncActiveIntoStore();

  const copy = window.confirm(
    `Copy details from “${activeProfileName()}” into the new profile?\n\nOK = copy · Cancel = start blank`
  );
  FoxFillProfiles.addProfile(profileStore, trimmed, PROFILE_KEYS, copy);
  await persistStore();
  applyActiveProfileToUi();
  renderProfileSelect();
  setStatus(`Created “${trimmed}”.`, "is-success");
  activateTab("personal");
}

async function renameActiveProfile() {
  if (!profileStore || typeof FoxFillProfiles === "undefined") return;
  const active = FoxFillProfiles.getActive(profileStore);
  if (!active) return;
  const name = window.prompt("Rename profile", active.name);
  if (name == null) return;
  const trimmed = String(name).trim();
  if (!trimmed) return;
  FoxFillProfiles.renameProfile(profileStore, active.id, trimmed);
  await persistStore();
  renderProfileSelect();
  setStatus(`Renamed to “${trimmed}”.`, "is-success");
}

async function deleteActiveProfile() {
  if (!profileStore || typeof FoxFillProfiles === "undefined") return;
  const active = FoxFillProfiles.getActive(profileStore);
  if (!active) return;
  const list = FoxFillProfiles.listProfiles(profileStore);
  if (list.length <= 1) {
    setError("You need at least one profile.");
    return;
  }
  const ok = window.confirm(
    `Delete profile “${active.name}”? This can’t be undone.`
  );
  if (!ok) return;
  const result = FoxFillProfiles.deleteProfile(profileStore, active.id);
  if (!result.ok) {
    setError("Couldn’t delete that profile.");
    return;
  }
  await persistStore();
  applyActiveProfileToUi();
  renderProfileSelect();
  setStatus(`Deleted. Now using “${activeProfileName()}”.`, "is-success");
}

function setupProfileControls() {
  if (profileSelect) {
    profileSelect.addEventListener("change", () => {
      void switchProfile(profileSelect.value);
    });
  }
  if (profileNewBtn) {
    profileNewBtn.addEventListener("click", () => {
      void createProfile();
    });
  }
  if (profileRenameBtn) {
    profileRenameBtn.addEventListener("click", () => {
      void renameActiveProfile();
    });
  }
  if (profileDeleteBtn) {
    profileDeleteBtn.addEventListener("click", () => {
      void deleteActiveProfile();
    });
  }
}

function setEncryptionError(message) {
  if (!encryptionError) return;
  encryptionError.hidden = !message;
  encryptionError.textContent = message || "";
}

function updateEncryptionUi() {
  const enabled = Boolean(profileStore?.encryptionEnabled);
  if (encryptionStatus) {
    encryptionStatus.textContent = enabled
      ? "Profiles are encrypted on this device. Unlock lasts for this browser session."
      : "Profiles are stored locally without a passphrase.";
  }
  if (encryptionOffControls) encryptionOffControls.hidden = enabled;
  if (encryptionOnControls) encryptionOnControls.hidden = !enabled;
  if (enableRecoveryEmail && !enableRecoveryEmail.value && profile.email) {
    enableRecoveryEmail.value = profile.email;
  }
}

function renderCustomFields() {
  if (!customFieldList) return;
  customFieldList.innerHTML = "";
  if (!customFields.length) {
    const empty = document.createElement("li");
    empty.className = "more-copy";
    empty.textContent = "No custom fields yet.";
    customFieldList.append(empty);
    return;
  }

  for (const cf of customFields) {
    const li = document.createElement("li");
    li.className = "custom-item";
    li.dataset.id = cf.id;

    const top = document.createElement("div");
    top.className = "custom-item-top";

    const label = document.createElement("span");
    label.className = "custom-item-label";
    label.textContent = cf.label;

    const remove = document.createElement("button");
    remove.type = "button";
    remove.className = "custom-item-remove";
    remove.textContent = "Remove";
    remove.addEventListener("click", () => {
      void removeCustomField(cf.id);
    });

    top.append(label, remove);

    const valueInput = document.createElement("input");
    valueInput.type = "text";
    valueInput.value = cf.value || "";
    valueInput.placeholder = "Value";
    valueInput.addEventListener("change", () => {
      cf.value = valueInput.value;
      void saveCustomFields();
    });

    const aliasInput = document.createElement("input");
    aliasInput.type = "text";
    aliasInput.value = (cf.aliases || []).join(", ");
    aliasInput.placeholder = "Aliases, comma-separated";
    aliasInput.addEventListener("change", () => {
      cf.aliases = aliasInput.value
        .split(",")
        .map((a) => a.trim())
        .filter(Boolean);
      void saveCustomFields();
    });

    li.append(top, valueInput, aliasInput);
    customFieldList.append(li);
  }
}

async function saveCustomFields() {
  // Pull latest edits from list inputs (in case change hasn't fired yet).
  if (customFieldList) {
    for (const li of customFieldList.querySelectorAll(".custom-item")) {
      const id = li.dataset.id;
      const cf = customFields.find((item) => item.id === id);
      if (!cf) continue;
      const inputs = li.querySelectorAll("input");
      if (inputs[0]) cf.value = inputs[0].value;
      if (inputs[1]) {
        cf.aliases = inputs[1].value
          .split(",")
          .map((a) => a.trim())
          .filter(Boolean);
      }
    }
  }
  syncActiveIntoStore();
  await persistStore();
  if (customSaveMsg) {
    customSaveMsg.hidden = false;
    window.setTimeout(() => {
      customSaveMsg.hidden = true;
    }, 1200);
  }
  refreshMatchesForActiveProfile();
}

async function removeCustomField(id) {
  customFields = customFields.filter((cf) => cf.id !== id);
  await saveCustomFields();
  renderCustomFields();
}

async function addCustomField(event) {
  event.preventDefault();
  if (!customFieldForm) return;
  const data = new FormData(customFieldForm);
  const label = String(data.get("label") || "").trim();
  if (!label) return;
  const aliases = String(data.get("aliases") || "")
    .split(",")
    .map((a) => a.trim())
    .filter(Boolean);
  const value = String(data.get("value") || "").trim();
  const id =
    globalThis.crypto?.randomUUID?.() ||
    `cf_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
  customFields.push({ id, label, aliases, value });
  customFieldForm.reset();
  renderCustomFields();
  await saveCustomFields();
}

async function unlockVault() {
  if (!unlockPassphrase) return;
  const passphrase = unlockPassphrase.value;
  if (!passphrase) {
    if (unlockError) {
      unlockError.hidden = false;
      unlockError.textContent = "Enter your passphrase.";
    }
    return;
  }
  try {
    profileStore = await FoxFillProfiles.loadStore(PROFILE_KEYS, {
      passphrase,
    });
    vaultLocked = false;
    setLockedUi(false);
    unlockPassphrase.value = "";
    applyActiveProfileToUi();
    renderProfileSelect();
    setStatus("Unlocked for this browser session.", "is-success");
  } catch (err) {
    if (unlockError) {
      unlockError.hidden = false;
      unlockError.textContent =
        err?.message === "Wrong passphrase"
          ? "Wrong passphrase."
          : "Couldn’t unlock. Try again.";
    }
  }
}

async function recoverWithEmail() {
  const email = unlockRecoveryEmail?.value || "";
  if (!email.trim()) {
    if (unlockError) {
      unlockError.hidden = false;
      unlockError.textContent = "Enter the recovery email.";
    }
    return;
  }
  try {
    profileStore = await FoxFillProfiles.loadStore(PROFILE_KEYS, {
      recoveryEmail: email,
    });
    vaultLocked = false;
    setLockedUi(false);
    applyActiveProfileToUi();
    renderProfileSelect();

    // After email recovery, require a new passphrase (old one may be lost).
    const next = window.prompt(
      "Recovery worked. Set a new passphrase (min 6 characters):"
    );
    if (next && next.length >= 6) {
      const confirmNext = window.prompt("Confirm new passphrase:");
      if (confirmNext === next) {
        profileStore.encryptionEnabled = true;
        await FoxFillProfiles.saveStore(profileStore, {
          passphrase: next,
          recoveryEmail:
            profile.email || FoxFillCrypto.normalizeEmail(email),
        });
        setStatus("Recovered — new passphrase saved for this session.", "is-success");
      } else {
        profileStore.encryptionEnabled = false;
        await FoxFillProfiles.saveStore(profileStore);
        setStatus(
          "Recovered. Passphrases didn’t match — encryption turned off for now.",
          "is-empty"
        );
      }
    } else {
      profileStore.encryptionEnabled = false;
      await FoxFillProfiles.saveStore(profileStore);
      setStatus(
        "Recovered. Encryption turned off — re-enable under More when ready.",
        "is-empty"
      );
    }
    updateEncryptionUi();
    if (unlockRecoveryEmail) unlockRecoveryEmail.value = "";
  } catch (err) {
    if (unlockError) {
      unlockError.hidden = false;
      unlockError.textContent =
        err?.message ||
        "Recovery failed. Check the email, or reset the vault.";
    }
  }
}

async function resetVault() {
  const ok = window.confirm(
    "Erase the encrypted vault and start fresh?\n\nAll encrypted profiles will be deleted. This cannot be undone."
  );
  if (!ok) return;
  const sure = window.confirm("Really wipe encrypted FoxFill data on this device?");
  if (!sure) return;
  try {
    await chrome.storage.local.remove(FoxFillProfiles.STORE_KEY);
    await FoxFillCrypto.clearSessionUnlocked();
    profileStore = FoxFillProfiles.defaultStore(PROFILE_KEYS);
    await FoxFillProfiles.saveStore(profileStore);
    vaultLocked = false;
    setLockedUi(false);
    applyActiveProfileToUi();
    renderProfileSelect();
    setStatus("Vault reset. Add your details again under Personal.", "is-success");
  } catch (err) {
    if (unlockError) {
      unlockError.hidden = false;
      unlockError.textContent = err?.message || "Couldn’t reset vault.";
    }
  }
}

async function enableEncryption() {
  setEncryptionError("");
  const a = enablePassphrase?.value || "";
  const b = enablePassphrase2?.value || "";
  const recovery =
    enableRecoveryEmail?.value?.trim() ||
    profile.email ||
    "";
  if (a.length < 6) {
    setEncryptionError("Use at least 6 characters.");
    return;
  }
  if (a !== b) {
    setEncryptionError("Passphrases don’t match.");
    return;
  }
  if (!recovery || !recovery.includes("@")) {
    setEncryptionError(
      "Add a recovery email (use your profile email) before enabling encryption."
    );
    return;
  }
  readFormIntoProfile(personalForm);
  readFormIntoProfile(addressForm);
  syncActiveIntoStore();
  profileStore.encryptionEnabled = true;
  try {
    await FoxFillProfiles.saveStore(profileStore, {
      passphrase: a,
      recoveryEmail: recovery,
    });
    if (enablePassphrase) enablePassphrase.value = "";
    if (enablePassphrase2) enablePassphrase2.value = "";
    updateEncryptionUi();
    setStatus("Encryption enabled (email recovery on).", "is-success");
  } catch (err) {
    profileStore.encryptionEnabled = false;
    setEncryptionError(err?.message || "Couldn’t enable encryption.");
  }
}

async function disableEncryption() {
  setEncryptionError("");
  const passphrase = window.prompt(
    "Enter your passphrase to turn off encryption"
  );
  if (passphrase == null) return;
  try {
    // Ensure we can decrypt with provided passphrase
    const peek = await FoxFillProfiles.peekEncryption();
    if (peek.encrypted) {
      await FoxFillCrypto.decryptStore(peek.envelope, passphrase);
    }
    profileStore.encryptionEnabled = false;
    await FoxFillProfiles.saveStore(profileStore);
    await FoxFillCrypto.clearSessionUnlocked();
    updateEncryptionUi();
    setStatus("Encryption turned off. Data stays local.", "is-success");
  } catch {
    setEncryptionError("Wrong passphrase — encryption stays on.");
  }
}

async function lockNow() {
  syncActiveIntoStore();
  try {
    await persistStore();
  } catch {
    // still lock
  }
  await FoxFillCrypto.clearSessionUnlocked();
  lastMatches = null;
  clearReview();
  vaultLocked = true;
  setLockedUi(true);
}

function activeCustomPatterns() {
  if (typeof FoxFillProfiles === "undefined") return [];
  return FoxFillProfiles.customPatternsFromFields(customFields);
}

function setupPasswordToggles() {
  document.querySelectorAll(".pw-toggle").forEach((btn) => {
    btn.addEventListener("click", () => {
      const id = btn.getAttribute("data-pw-target");
      const input = id ? document.getElementById(id) : null;
      if (!input) return;
      const show = input.type === "password";
      input.type = show ? "text" : "password";
      btn.textContent = show ? "Hide" : "Show";
      btn.setAttribute("aria-label", show ? "Hide passphrase" : "Show passphrase");
    });
  });
}

function setupMoreControls() {
  setupPasswordToggles();
  if (customFieldForm) {
    customFieldForm.addEventListener("submit", (event) => {
      void addCustomField(event);
    });
  }
  const saveCustomFieldsBtn = document.getElementById("saveCustomFieldsBtn");
  if (saveCustomFieldsBtn) {
    saveCustomFieldsBtn.addEventListener("click", () => {
      void saveCustomFields();
    });
  }
  if (unlockBtn) {
    unlockBtn.addEventListener("click", () => {
      void unlockVault();
    });
  }
  if (unlockPassphrase) {
    unlockPassphrase.addEventListener("keydown", (event) => {
      if (event.key === "Enter") void unlockVault();
    });
  }
  if (recoverBtn) {
    recoverBtn.addEventListener("click", () => {
      void recoverWithEmail();
    });
  }
  if (unlockRecoveryEmail) {
    unlockRecoveryEmail.addEventListener("keydown", (event) => {
      if (event.key === "Enter") void recoverWithEmail();
    });
  }
  if (resetVaultBtn) {
    resetVaultBtn.addEventListener("click", () => {
      void resetVault();
    });
  }
  if (enableEncryptionBtn) {
    enableEncryptionBtn.addEventListener("click", () => {
      void enableEncryption();
    });
  }
  if (disableEncryptionBtn) {
    disableEncryptionBtn.addEventListener("click", () => {
      void disableEncryption();
    });
  }
  if (lockNowBtn) {
    lockNowBtn.addEventListener("click", () => {
      void lockNow();
    });
  }
}

function openFullSettings() {
  if (chrome.runtime.openOptionsPage) {
    chrome.runtime.openOptionsPage();
    return;
  }
  const url = chrome.runtime.getURL("options/options.html");
  chrome.tabs.create({ url });
}

function setupSettingsLinks() {
  openSettingsBtn?.addEventListener("click", openFullSettings);
  openSettingsFooterBtn?.addEventListener("click", openFullSettings);
  openSettingsFromPersonal?.addEventListener("click", openFullSettings);
}

function setupTabs() {
  const tabs = document.querySelectorAll(".tab");

  tabs.forEach((tab) => {
    tab.addEventListener("click", () => {
      activateTab(tab.dataset.tab);
    });
  });

  if (nudgePersonalBtn) {
    nudgePersonalBtn.addEventListener("click", () => activateTab("personal"));
  }
}

async function getActiveTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return tabs[0] || null;
}

/**
 * Merge scan results from every frame (Discovery quote forms live in iframes).
 * Phone compounds are applied per-frame so dial companions stay paired.
 */
function collectMatchesFromFrames(results) {
  const buckets = new Map();
  let framesScanned = 0;
  let framesWithFields = 0;

  for (const entry of results || []) {
    framesScanned += 1;
    const payload = entry?.result;
    if (!payload || payload.ok !== true || !Array.isArray(payload.matches)) {
      continue;
    }
    const frameId = entry.frameId ?? 0;
    if (payload.matches.length) framesWithFields += 1;
    if (!buckets.has(frameId)) buckets.set(frameId, []);
    for (const match of payload.matches) {
      buckets.get(frameId).push({
        ...match,
        frameId,
        frameHref: payload.frame?.href || "",
      });
    }
  }

  const merged = [];
  let globalIndex = 0;

  for (const [frameId, raw] of buckets) {
    let local = raw.map((m, i) => ({ ...m, index: i, frameId }));
    if (typeof FoxFillApplyPhoneCompounds === "function") {
      local = FoxFillApplyPhoneCompounds(local, {
        phone: profile.phone || "",
        country: profile.country || "",
        dateOfBirth: profile.dateOfBirth || "",
      });
    }

    const localToGlobal = new Map();
    for (const m of local) {
      localToGlobal.set(m.index, globalIndex);
      merged.push({
        ...m,
        index: globalIndex,
        frameId,
        localIndex: m.index,
      });
      globalIndex += 1;
    }

    for (const m of merged) {
      if (m.frameId !== frameId) continue;
      if (m.compound && m.compound.pairedIndex != null) {
        const mapped = localToGlobal.get(m.compound.pairedIndex);
        if (mapped != null) {
          m.compound = { ...m.compound, pairedIndex: mapped };
        }
      }
    }
  }

  return { matches: merged, framesScanned, framesWithFields };
}

async function scanActiveTab() {
  setError("");
  setStatus("Scanning this page…");
  clearReview();
  showEmptyState(false);
  lastMatches = null;
  lastTabId = null;
  scanBtn.disabled = true;

  try {
    const tab = await getActiveTab();
    if (!tab || tab.id == null) {
      setStatus("No active tab to scan.", "is-error");
      setError("Open a webpage in this window, then try Scan Form again.");
      showEmptyState(true);
      return;
    }

    if (isRestrictedUrl(tab.url || "")) {
      setStatus("This page can’t be scanned.", "is-error");
      setError(restrictedPageMessage(tab.url || ""));
      showEmptyState(true);
      return;
    }

    await chrome.scripting.executeScript({
      target: { tabId: tab.id, allFrames: true },
      files: [
        "data/fieldPatterns.js",
        "data/countries.js",
        "data/phoneParse.js",
        "data/dateFormat.js",
        "data/fitValue.js",
        "content/matcher.js",
      ],
    });

    const customPatterns = activeCustomPatterns();
    await chrome.scripting.executeScript({
      target: { tabId: tab.id, allFrames: true },
      func: (patterns) => {
        const bag = globalThis.FoxFillFieldPatterns;
        if (!bag || !Array.isArray(bag.fields)) return;
        bag.fields = bag.fields.filter((f) => !f.custom);
        if (Array.isArray(patterns) && patterns.length) {
          bag.fields.push(...patterns);
        }
      },
      args: [customPatterns],
    });

    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id, allFrames: true },
      files: ["content/scanner.js"],
    });

    const collected = collectMatchesFromFrames(results);
    let matches = collected.matches;

    if (!results?.length) {
      setStatus("Scan didn’t return fields.", "is-error");
      setError("Reload the webpage, then click Scan Form again.");
      showEmptyState(true);
      return;
    }

    lastMatches = matches;
    lastTabId = tab.id;

    const count = matches.length;
    const willFill = matches.filter((m) => isWillFill(m)).length;
    const review = matches.filter((m) => m.status === "needs_review").length;

    console.groupCollapsed(
      `[FoxFill] Review — ${count} fields across ${collected.framesWithFields}/${collected.framesScanned} frames`
    );
    console.table(
      matches.map((m) => ({
        label: primaryClue(m.fingerprint),
        status: m.status,
        profile: m.profileKey || "",
        fill: resolvedFillValue(m),
        mode: m.fillMode || m.compound?.scenario || "",
        frame: m.frameId,
        score: m.score || 0,
      }))
    );
    console.log("Full matches:", matches);
    console.groupEnd();

    if (count === 0) {
      setStatus("No fillable fields on this page.", "is-empty");
      setError("");
      showEmptyState(
        true,
        "Nothing to fill here",
        collected.framesScanned > 1
          ? "Scanned nested frames too, but found no usable inputs. The form may still be loading — wait a second and scan again."
          : "No text inputs found. If the form is inside a login wall or still loading, wait and scan again."
      );
      return;
    }

    renderMatches(matches);
    void showPageOverlay(matches, tab.id);

    if (willFill === 0 && review === 0) {
      setStatus(
        `Found ${count} fields, but none matched your profile confidently.`,
        "is-empty"
      );
    } else if (willFill === 0 && review > 0) {
      setStatus(
        `Found ${count} fields — ${review} need a quick check before filling.`,
        "is-empty"
      );
    } else {
      const frameBit =
        collected.framesWithFields > 1
          ? ` across ${collected.framesWithFields} frames`
          : "";
      setStatus(
        `Ready — ${willFill} matched${review ? `, ${review} to review` : ""}${frameBit}.`,
        "is-success"
      );
    }

    if (isProfileThin()) {
      updateProfileNudge();
    }
  } catch (err) {
    console.error("FoxFill scan error:", err);
    setStatus("Couldn’t reach this tab.", "is-error");
    setError(
      "Reload the webpage, open FoxFill again, then click Scan Form."
    );
    showEmptyState(true);
  } finally {
    scanBtn.disabled = false;
  }
}

async function fillActiveTab() {
  setError("");
  fillBtn.classList.remove("is-ready");
  const fillable = selectedFillable();
  if (!fillable.length) {
    setStatus("Nothing selected.", "is-empty");
    setError("Tick fields under Ready or Needs review, then try Fill again.");
    return;
  }

  fillBtn.disabled = true;
  scanBtn.disabled = true;
  setStatus(`Filling ${fillable.length} field${fillable.length === 1 ? "" : "s"}…`);

  try {
    const tab = await getActiveTab();
    if (!tab || tab.id == null) {
      setStatus("No active tab.", "is-error");
      setError("Keep the form page open in this window, then fill again.");
      return;
    }

    if (lastTabId != null && tab.id !== lastTabId) {
      setStatus("Tab changed since scan.", "is-error");
      setError("Scan this page again, then fill.");
      updateFillButton();
      return;
    }

    if (isRestrictedUrl(tab.url || "")) {
      setStatus("This page can’t be filled.", "is-error");
      setError(restrictedPageMessage(tab.url || ""));
      return;
    }

    const phoneParsed =
      typeof FoxFillPhoneParse !== "undefined"
        ? FoxFillPhoneParse.parsePhone(
            profile.phone || "",
            profile.country || ""
          )
        : null;

    const fills = fillable.map((m) => {
      const value = resolvedFillValue(m);
      const hints = {};
      if (m.profileKey === "phoneCountryCode" || m.compound?.role === "dial") {
        if (phoneParsed?.dialDigits) hints.dialDigits = phoneParsed.dialDigits;
        if (profile.country) hints.country = profile.country;
      }
      if (Array.isArray(m.fillCandidates) && m.fillCandidates.length) {
        hints.candidates = m.fillCandidates;
      }
      return {
        profileKey: m.profileKey,
        value,
        fingerprint: m.fingerprint,
        allowOverwrite: false,
        hints,
        frameId: m.frameId ?? 0,
        phoneParsed:
          m.profileKey === "phone" || m.fillMode?.startsWith?.("phone")
            ? phoneParsed
            : null,
      };
    });

    const byFrame = new Map();
    for (const item of fills) {
      const fid = item.frameId ?? 0;
      if (!byFrame.has(fid)) byFrame.set(fid, []);
      byFrame.get(fid).push(item);
    }

    let filled = 0;
    let already = 0;
    let skipped = 0;
    const allFillResults = [];

    for (const [frameId, frameFills] of byFrame) {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id, frameIds: [frameId] },
        files: [
          "data/countries.js",
          "data/phoneParse.js",
          "data/fitValue.js",
          "content/filler.js",
        ],
      });

      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id, frameIds: [frameId] },
        func: (payload) => {
          if (typeof globalThis.FoxFillFillFields !== "function") {
            return { ok: false, error: "filler unavailable" };
          }
          return globalThis.FoxFillFillFields(payload);
        },
        args: [{ fills: frameFills }],
      });

      const outcome = results?.[0]?.result;
      if (!outcome || outcome.ok !== true) {
        setStatus("Fill didn’t complete.", "is-error");
        setError(
          outcome?.error ||
            "Reload the webpage, scan again, then fill. If the form is in an iframe, wait for it to finish loading."
        );
        return;
      }

      filled += outcome.filled || 0;
      already += outcome.already || 0;
      skipped += outcome.skipped || 0;
      if (Array.isArray(outcome.results)) {
        allFillResults.push(...outcome.results);
      }
    }

    console.groupCollapsed("[FoxFill] Fill outcome");
    console.table(allFillResults);
    console.groupEnd();

    const parts = [];
    if (filled) parts.push(`${filled} filled`);
    if (already) parts.push(`${already} already set`);
    if (skipped) parts.push(`${skipped} skipped`);
    const kind =
      filled > 0
        ? "is-success"
        : skipped > 0 && !already
          ? "is-empty"
          : "is-success";
    setStatus(
      parts.length ? `Done — ${parts.join(", ")}.` : "Fill finished.",
      kind
    );
    if (skipped > 0) {
      setError(
        "Some fields already had values and were left alone. Clear them on the page if you want FoxFill to overwrite."
      );
    }
  } catch (err) {
    console.error("FoxFill fill error:", err);
    setStatus("Couldn’t fill this tab.", "is-error");
    setError(
      "Reload the webpage, scan again, then fill."
    );
  } finally {
    scanBtn.disabled = false;
    updateFillButton();
  }
}

scanBtn.addEventListener("click", () => {
  void scanActiveTab();
});

fillBtn.addEventListener("click", () => {
  void fillActiveTab();
});

toggleUnmatched.addEventListener("click", () => {
  const open = toggleUnmatched.getAttribute("aria-expanded") === "true";
  const next = !open;
  toggleUnmatched.setAttribute("aria-expanded", next ? "true" : "false");
  listUnmatched.hidden = !next;
  listUnmatched.classList.toggle("is-collapsed", !next);
});

personalForm.addEventListener("submit", (event) => {
  event.preventDefault();
  void saveProfile(personalForm, personalSaveMsg);
});

addressForm.addEventListener("submit", (event) => {
  event.preventDefault();
  void saveProfile(addressForm, addressSaveMsg);
});

setupTabs();
setupProfileControls();
setupMoreControls();
setupSettingsLinks();
updateFillButton();
void initTheme();
void loadProfile();

async function initTheme() {
  const toggle = document.getElementById("darkModeToggle");
  const pageToggle = document.getElementById("pageButtonToggle");
  const pageStatus = document.getElementById("pageButtonStatus");
  if (typeof FoxFillPrefs === "undefined") return;
  const prefs = await FoxFillPrefs.loadPrefs();
  FoxFillPrefs.applyTheme(prefs.darkMode);
  if (toggle) {
    toggle.checked = Boolean(prefs.darkMode);
    toggle.addEventListener("change", () => {
      void (async () => {
        const next = await FoxFillPrefs.savePrefs({ darkMode: toggle.checked });
        FoxFillPrefs.applyTheme(next.darkMode);
      })();
    });
  }
  if (pageToggle) {
    pageToggle.checked = Boolean(prefs.pageButton);
    pageToggle.addEventListener("change", () => {
      void (async () => {
        pageToggle.disabled = true;
        const result = await FoxFillPrefs.setPageButtonEnabled(pageToggle.checked);
        pageToggle.checked = Boolean(result.enabled);
        pageToggle.disabled = false;
        if (pageStatus) {
          pageStatus.textContent = result.ok
            ? result.enabled
              ? "On — reload open tabs if you don’t see the icon yet, then click it to fill."
              : "Off — the page icon won’t appear on websites."
            : result.error || "Couldn’t update page button.";
        }
      })();
    });
  }
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local" || !changes[FoxFillPrefs.KEY]) return;
    const next = changes[FoxFillPrefs.KEY].newValue || {};
    const dark = Boolean(next.darkMode);
    FoxFillPrefs.applyTheme(dark);
    if (toggle) toggle.checked = dark;
    if (pageToggle) pageToggle.checked = Boolean(next.pageButton);
  });
}
