/**
 * FoxFill full settings page (local only).
 */
(function initOptionsPage() {
  const PROFILE_KEYS = [
    "title",
    "firstName",
    "lastName",
    "idNumber",
    "passportNumber",
    "email",
    "phone",
    "dateOfBirth",
    "residenceType",
    "addressLine1",
    "addressLine2",
    "suburb",
    "city",
    "province",
    "postalCode",
    "country",
  ];

  const personalForm = document.getElementById("personalForm");
  const addressForm = document.getElementById("addressForm");
  const profileSelect = document.getElementById("profileSelect");
  const profileNewBtn = document.getElementById("profileNewBtn");
  const profileRenameBtn = document.getElementById("profileRenameBtn");
  const profileDeleteBtn = document.getElementById("profileDeleteBtn");
  const customFieldList = document.getElementById("customFieldList");
  const customFieldForm = document.getElementById("customFieldForm");
  const saveAllBtn = document.getElementById("saveAllBtn");
  const saveStatus = document.getElementById("saveStatus");
  const unlockGate = document.getElementById("unlockGate");
  const unlockPassphrase = document.getElementById("unlockPassphrase");
  const unlockBtn = document.getElementById("unlockBtn");
  const unlockError = document.getElementById("unlockError");
  const unlockRecoveryEmail = document.getElementById("unlockRecoveryEmail");
  const recoverBtn = document.getElementById("recoverBtn");
  const encryptionStatus = document.getElementById("encryptionStatus");
  const encryptionOffControls = document.getElementById("encryptionOffControls");
  const encryptionOnControls = document.getElementById("encryptionOnControls");
  const enablePassphrase = document.getElementById("enablePassphrase");
  const enablePassphrase2 = document.getElementById("enablePassphrase2");
  const enableRecoveryEmail = document.getElementById("enableRecoveryEmail");
  const enableEncryptionBtn = document.getElementById("enableEncryptionBtn");
  const disableEncryptionBtn = document.getElementById("disableEncryptionBtn");
  const lockNowBtn = document.getElementById("lockNowBtn");
  const encryptionError = document.getElementById("encryptionError");
  const phoneInput = document.getElementById("phoneInput");
  const countryInput = document.getElementById("countryInput");
  const countryBtn = document.getElementById("countryBtn");
  const countryMenu = document.getElementById("countryMenu");
  const countryDd = document.getElementById("countryDd");
  const provinceFieldLabel = document.getElementById("provinceFieldLabel");
  const postalCodeFieldLabel = document.getElementById("postalCodeFieldLabel");

  /** @type {Record<string, string>} */
  let profile = emptyProfile();
  /** @type {Array<{id:string,label:string,aliases:string[],value:string}>} */
  let customFields = [];
  /** @type {object|null} */
  let profileStore = null;
  let vaultLocked = false;
  let saveTimer = 0;
  let countryReady = false;

  function emptyProfile() {
    return Object.fromEntries(PROFILE_KEYS.map((key) => [key, ""]));
  }

  function setUnlockError(message) {
    if (!unlockError) return;
    unlockError.hidden = !message;
    unlockError.textContent = message || "";
  }

  function setEncryptionError(message) {
    if (!encryptionError) return;
    encryptionError.hidden = !message;
    encryptionError.textContent = message || "";
  }

  function flashSaved() {
    if (!saveStatus) return;
    saveStatus.hidden = false;
    window.clearTimeout(saveTimer);
    saveTimer = window.setTimeout(() => {
      saveStatus.hidden = true;
    }, 1600);
  }

  function setLockedUi(locked) {
    vaultLocked = locked;
    document.body.classList.toggle("is-locked", locked);
    if (unlockGate) unlockGate.hidden = !locked;
    if (!locked) setUnlockError("");
  }

  function guessDefaultCountry() {
    const lang =
      (typeof chrome !== "undefined" && chrome.i18n?.getUILanguage?.()) ||
      (typeof navigator !== "undefined" && navigator.language) ||
      "";
    return (
      globalThis.FoxFillCountries?.guessCountryFromLocale?.(lang) ||
      "United States"
    );
  }

  function isProfileBlank(data) {
    return PROFILE_KEYS.every((key) => !String(data?.[key] || "").trim());
  }

  function seedCountryIfNeeded(data) {
    if (!data || String(data.country || "").trim()) return false;
    if (!isProfileBlank(data)) return false;
    data.country = guessDefaultCountry();
    return true;
  }

  function updatePhonePlaceholder(countryName) {
    if (!phoneInput) return;
    phoneInput.placeholder =
      globalThis.FoxFillCountries?.phonePlaceholderForCountry?.(countryName) ||
      "+…";
  }

  function updateAddressLabels(countryName) {
    const labels =
      globalThis.FoxFillCountries?.addressLabelsForCountry?.(countryName) || {
        province: "Province",
        postalCode: "Postal Code",
      };
    if (provinceFieldLabel) provinceFieldLabel.textContent = labels.province;
    if (postalCodeFieldLabel) {
      postalCodeFieldLabel.textContent = labels.postalCode;
    }
  }

  function setCountryButtonLabel(value) {
    if (!countryBtn) return;
    const label = countryBtn.querySelector(".country-dd-label");
    if (!label) return;
    const text = String(value || "").trim();
    label.textContent = text || "Select country…";
    label.classList.toggle("is-placeholder", !text);
  }

  function setCountryUi(countryName) {
    const value = String(countryName || "").trim();
    if (countryInput) countryInput.value = value;
    setCountryButtonLabel(value);
    updatePhonePlaceholder(value);
    updateAddressLabels(value);
  }

  function closeCountryMenu() {
    if (!countryDd) return;
    countryDd.classList.remove("is-open");
    if (countryBtn) countryBtn.setAttribute("aria-expanded", "false");
    if (countryMenu) countryMenu.hidden = true;
  }

  function countryFilterMatch(text, value, query) {
    const q = String(query || "")
      .trim()
      .toLowerCase();
    if (!q) return true;
    const label = String(text || "").toLowerCase();
    const raw = String(value || "").toLowerCase();
    return label.startsWith(q) || label.includes(q) || raw.startsWith(q);
  }

  function fillCountryMenu(selected, onPick) {
    if (!countryMenu) return;
    countryMenu.innerHTML = "";

    const filterLi = document.createElement("li");
    filterLi.className = "country-dd-filter-row";
    const filter = document.createElement("input");
    filter.type = "search";
    filter.className = "country-dd-filter";
    filter.placeholder = "Type to filter…";
    filter.setAttribute("autocomplete", "off");
    filter.setAttribute("aria-label", "Filter countries");
    filterLi.append(filter);
    countryMenu.append(filterLi);

    const optionsHost = document.createElement("li");
    optionsHost.className = "country-dd-options-host";
    const optionsList = document.createElement("ul");
    optionsList.className = "country-dd-options";
    optionsHost.append(optionsList);
    countryMenu.append(optionsHost);

    const countries = globalThis.FoxFillCountries?.listCountries?.() || [];
    const items = [["", "Select country…"], ...countries.map((c) => [c.name, c.name])];

    function renderOptions(query) {
      optionsList.innerHTML = "";
      const q = String(query || "").trim();
      let shown = 0;
      for (const [value, text] of items) {
        if (!value && q) continue;
        if (value && !countryFilterMatch(text, value, q)) continue;
        const li = document.createElement("li");
        const opt = document.createElement("button");
        opt.type = "button";
        opt.className = "country-dd-option";
        opt.setAttribute("role", "option");
        opt.dataset.value = value;
        opt.textContent = text;
        if (value && value === selected) opt.classList.add("is-active");
        opt.addEventListener("click", (event) => {
          event.preventDefault();
          onPick(value);
          closeCountryMenu();
        });
        li.append(opt);
        optionsList.append(li);
        shown += 1;
      }
      if (!shown) {
        const empty = document.createElement("li");
        empty.className = "country-dd-empty";
        empty.textContent = "No matches";
        optionsList.append(empty);
      }
      const active = optionsList.querySelector(".is-active");
      if (active) active.scrollIntoView({ block: "nearest" });
    }

    filter.addEventListener("input", () => renderOptions(filter.value));
    filter.addEventListener("keydown", (event) => {
      if (event.key === "Enter") {
        event.preventDefault();
        const first = optionsList.querySelector(".country-dd-option");
        if (first) first.click();
      } else if (event.key === "Escape") {
        event.preventDefault();
        closeCountryMenu();
      }
    });
    filter.addEventListener("click", (event) => event.stopPropagation());
    renderOptions("");
  }

  function openCountryMenu() {
    if (!countryDd || !countryBtn || !countryMenu) return;
    const selected = String(countryInput?.value || "").trim();
    fillCountryMenu(selected, (value) => {
      setCountryUi(value);
      profile.country = value;
    });
    countryDd.classList.add("is-open");
    countryBtn.setAttribute("aria-expanded", "true");
    countryMenu.hidden = false;
    const filter = countryMenu.querySelector(".country-dd-filter");
    if (filter) {
      filter.value = "";
      filter.dispatchEvent(new Event("input", { bubbles: false }));
      queueMicrotask(() => filter.focus());
    }
  }

  function populateCountrySelect() {
    if (!countryBtn || !countryMenu || !countryDd || countryReady) return;
    countryReady = true;
    setCountryUi(countryInput?.value || "");
    countryBtn.addEventListener("click", (event) => {
      event.preventDefault();
      const open = countryDd.classList.contains("is-open");
      if (open) closeCountryMenu();
      else openCountryMenu();
    });
    document.addEventListener("click", (event) => {
      if (!event.target.closest(".country-dd")) closeCountryMenu();
    });
  }

  function readFormIntoProfile(form) {
    if (!form) return;
    const data = new FormData(form);
    for (const [key, value] of data.entries()) {
      if (PROFILE_KEYS.includes(key)) {
        profile[key] = String(value || "");
      }
    }
  }

  function writeProfileIntoForms() {
    for (const form of [personalForm, addressForm]) {
      if (!form) continue;
      for (const el of form.elements) {
        if (!el.name || !PROFILE_KEYS.includes(el.name)) continue;
        if (el.name === "country") continue;
        el.value = profile[el.name] || "";
      }
    }
    setCountryUi(profile.country || "");
  }

  function syncActiveIntoStore() {
    if (!profileStore || typeof FoxFillProfiles === "undefined") return;
    readFormIntoProfile(personalForm);
    readFormIntoProfile(addressForm);
    FoxFillProfiles.upsertActiveData(
      profileStore,
      profile,
      PROFILE_KEYS,
      customFields
    );
  }

  async function persistStore(extraOpts) {
    if (!profileStore) return;
    await FoxFillProfiles.saveStore(profileStore, extraOpts);
    flashSaved();
  }

  function applyActiveProfileToUi() {
    const active = FoxFillProfiles.getActive(profileStore);
    profile = { ...emptyProfile(), ...(active?.data || {}) };
    customFields = FoxFillProfiles.normalizeCustomFields(
      active?.customFields || []
    );
    const seeded = seedCountryIfNeeded(profile);
    writeProfileIntoForms();
    renderCustomFields();
    updateEncryptionUi();
    if (seeded) {
      syncActiveIntoStore();
      void persistStore();
    }
  }

  function renderProfileSelect() {
    if (!profileSelect || !profileStore) return;
    const list = FoxFillProfiles.listProfiles(profileStore);
    profileSelect.innerHTML = "";
    for (const p of list) {
      const opt = document.createElement("option");
      opt.value = p.id;
      opt.textContent = p.name;
      if (p.id === profileStore.activeProfileId) opt.selected = true;
      profileSelect.appendChild(opt);
    }
  }

  function renderCustomFields() {
    if (!customFieldList) return;
    customFieldList.innerHTML = "";
    if (!customFields.length) {
      const empty = document.createElement("li");
      empty.className = "custom-item";
      empty.textContent = "No custom fields yet.";
      customFieldList.appendChild(empty);
      return;
    }
    for (const cf of customFields) {
      const li = document.createElement("li");
      li.className = "custom-item";
      li.dataset.id = cf.id;

      const label = document.createElement("div");
      label.className = "custom-item-label";
      label.textContent = cf.label;

      const aliases = document.createElement("input");
      aliases.type = "text";
      aliases.value = (cf.aliases || []).join(", ");
      aliases.placeholder = "Aliases, comma-separated";
      aliases.addEventListener("change", () => {
        cf.aliases = aliases.value
          .split(",")
          .map((a) => a.trim())
          .filter(Boolean);
      });

      const value = document.createElement("input");
      value.type = "text";
      value.value = cf.value || "";
      value.placeholder = "Value";
      value.addEventListener("change", () => {
        cf.value = value.value;
      });

      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "btn-ghost danger";
      remove.textContent = "Remove";
      remove.addEventListener("click", () => {
        void removeCustomField(cf.id);
      });

      li.append(label, aliases, value, remove);
      customFieldList.appendChild(li);
    }
  }

  async function removeCustomField(id) {
    customFields = customFields.filter((cf) => cf.id !== id);
    renderCustomFields();
    syncActiveIntoStore();
    await persistStore();
  }

  async function addCustomField(event) {
    event.preventDefault();
    if (!customFieldForm) return;
    const data = new FormData(customFieldForm);
    const label = String(data.get("label") || "").trim();
    if (!label) return;
    const aliases = String(data.get("aliases") || "")
      .split(",")
      .map((a) => a.trim())
      .filter(Boolean);
    const value = String(data.get("value") || "").trim();
    const id =
      globalThis.crypto?.randomUUID?.() ||
      `cf_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
    customFields.push({ id, label, aliases, value });
    customFieldForm.reset();
    renderCustomFields();
    syncActiveIntoStore();
    await persistStore();
  }

  function updateEncryptionUi() {
    const on = Boolean(profileStore?.encryptionEnabled);
    if (encryptionStatus) {
      encryptionStatus.textContent = on
        ? "Encryption is on. Profiles stay on this device, locked between sessions until you unlock."
        : "Profiles are stored locally without a passphrase.";
    }
    if (encryptionOffControls) encryptionOffControls.hidden = on;
    if (encryptionOnControls) encryptionOnControls.hidden = !on;
  }

  async function unlockVault() {
    const passphrase = unlockPassphrase?.value || "";
    if (!passphrase) {
      setUnlockError("Enter your passphrase.");
      return;
    }
    try {
      profileStore = await FoxFillProfiles.loadStore(PROFILE_KEYS, {
        passphrase,
      });
      setLockedUi(false);
      if (unlockPassphrase) unlockPassphrase.value = "";
      applyActiveProfileToUi();
      renderProfileSelect();
    } catch {
      setUnlockError("Wrong passphrase.");
    }
  }

  async function recoverWithEmail() {
    const email = unlockRecoveryEmail?.value || "";
    if (!email.trim()) {
      setUnlockError("Enter the recovery email.");
      return;
    }
    try {
      profileStore = await FoxFillProfiles.loadStore(PROFILE_KEYS, {
        recoveryEmail: email,
      });
      setLockedUi(false);
      applyActiveProfileToUi();
      renderProfileSelect();

      const next = window.prompt(
        "Recovery worked. Set a new passphrase (min 6 characters):"
      );
      if (next && next.length >= 6) {
        const confirmNext = window.prompt("Confirm new passphrase:");
        if (confirmNext === next) {
          profileStore.encryptionEnabled = true;
          await FoxFillProfiles.saveStore(profileStore, {
            passphrase: next,
            recoveryEmail:
              profile.email || FoxFillCrypto.normalizeEmail(email),
          });
        } else {
          profileStore.encryptionEnabled = false;
          await FoxFillProfiles.saveStore(profileStore);
        }
      } else {
        profileStore.encryptionEnabled = false;
        await FoxFillProfiles.saveStore(profileStore);
      }
      updateEncryptionUi();
      if (unlockRecoveryEmail) unlockRecoveryEmail.value = "";
    } catch (err) {
      setUnlockError(err?.message || "Recovery failed.");
    }
  }

  async function enableEncryption() {
    setEncryptionError("");
    const a = enablePassphrase?.value || "";
    const b = enablePassphrase2?.value || "";
    readFormIntoProfile(personalForm);
    readFormIntoProfile(addressForm);
    const recovery =
      enableRecoveryEmail?.value?.trim() || profile.email || "";
    if (a.length < 6) {
      setEncryptionError("Use at least 6 characters.");
      return;
    }
    if (a !== b) {
      setEncryptionError("Passphrases don’t match.");
      return;
    }
    if (!recovery || !recovery.includes("@")) {
      setEncryptionError("Add a recovery email before enabling encryption.");
      return;
    }
    syncActiveIntoStore();
    profileStore.encryptionEnabled = true;
    try {
      await FoxFillProfiles.saveStore(profileStore, {
        passphrase: a,
        recoveryEmail: recovery,
      });
      if (enablePassphrase) enablePassphrase.value = "";
      if (enablePassphrase2) enablePassphrase2.value = "";
      updateEncryptionUi();
      flashSaved();
    } catch (err) {
      profileStore.encryptionEnabled = false;
      setEncryptionError(err?.message || "Couldn’t enable encryption.");
    }
  }

  async function disableEncryption() {
    setEncryptionError("");
    const passphrase = window.prompt(
      "Enter your passphrase to turn off encryption"
    );
    if (passphrase == null) return;
    try {
      const peek = await FoxFillProfiles.peekEncryption();
      if (peek.encrypted) {
        await FoxFillCrypto.decryptStore(peek.envelope, passphrase);
      }
      syncActiveIntoStore();
      profileStore.encryptionEnabled = false;
      await FoxFillProfiles.saveStore(profileStore);
      await FoxFillCrypto.clearSessionUnlocked();
      updateEncryptionUi();
      flashSaved();
    } catch {
      setEncryptionError("Wrong passphrase — encryption stays on.");
    }
  }

  async function lockNow() {
    syncActiveIntoStore();
    try {
      await persistStore();
    } catch {
      // still lock
    }
    await FoxFillCrypto.clearSessionUnlocked();
    setLockedUi(true);
  }

  async function saveAll() {
    setEncryptionError("");
    syncActiveIntoStore();
    try {
      await persistStore();
    } catch (err) {
      setEncryptionError(err?.message || "Couldn’t save.");
    }
  }

  async function onProfileChange() {
    syncActiveIntoStore();
    try {
      await persistStore();
    } catch {
      // continue switch
    }
    FoxFillProfiles.setActive(profileStore, profileSelect.value);
    applyActiveProfileToUi();
    await persistStore();
  }

  async function onNewProfile() {
    const name = window.prompt("Name for the new profile:", "Work");
    if (name == null) return;
    const trimmed = name.trim();
    if (!trimmed) return;
    const copy = window.confirm(
      "Copy details from the current profile into the new one?"
    );
    syncActiveIntoStore();
    FoxFillProfiles.addProfile(profileStore, trimmed, PROFILE_KEYS, copy);
    applyActiveProfileToUi();
    renderProfileSelect();
    await persistStore();
  }

  async function onRenameProfile() {
    const active = FoxFillProfiles.getActive(profileStore);
    if (!active) return;
    const name = window.prompt("Rename profile:", active.name);
    if (name == null) return;
    FoxFillProfiles.renameProfile(profileStore, active.id, name);
    renderProfileSelect();
    await persistStore();
  }

  async function onDeleteProfile() {
    const active = FoxFillProfiles.getActive(profileStore);
    if (!active) return;
    const ok = window.confirm(
      `Delete profile “${active.name}”? This cannot be undone.`
    );
    if (!ok) return;
    const result = FoxFillProfiles.deleteProfile(profileStore, active.id);
    if (!result.ok) {
      window.alert("You need at least one profile.");
      return;
    }
    applyActiveProfileToUi();
    renderProfileSelect();
    await persistStore();
  }

  function setupPasswordToggles() {
    document.querySelectorAll(".pw-toggle").forEach((btn) => {
      btn.addEventListener("click", () => {
        const id = btn.getAttribute("data-pw-target");
        const input = id ? document.getElementById(id) : null;
        if (!input) return;
        const show = input.type === "password";
        input.type = show ? "text" : "password";
        btn.textContent = show ? "Hide" : "Show";
      });
    });
  }

  function bindEvents() {
    setupPasswordToggles();
    saveAllBtn?.addEventListener("click", () => {
      void saveAll();
    });
    profileSelect?.addEventListener("change", () => {
      void onProfileChange();
    });
    profileNewBtn?.addEventListener("click", () => {
      void onNewProfile();
    });
    profileRenameBtn?.addEventListener("click", () => {
      void onRenameProfile();
    });
    profileDeleteBtn?.addEventListener("click", () => {
      void onDeleteProfile();
    });
    customFieldForm?.addEventListener("submit", (event) => {
      void addCustomField(event);
    });
    unlockBtn?.addEventListener("click", () => {
      void unlockVault();
    });
    unlockPassphrase?.addEventListener("keydown", (event) => {
      if (event.key === "Enter") void unlockVault();
    });
    recoverBtn?.addEventListener("click", () => {
      void recoverWithEmail();
    });
    unlockRecoveryEmail?.addEventListener("keydown", (event) => {
      if (event.key === "Enter") void recoverWithEmail();
    });
    enableEncryptionBtn?.addEventListener("click", () => {
      void enableEncryption();
    });
    disableEncryptionBtn?.addEventListener("click", () => {
      void disableEncryption();
    });
    lockNowBtn?.addEventListener("click", () => {
      void lockNow();
    });
  }

  async function initTheme() {
    const toggle = document.getElementById("darkModeToggle");
    const pageToggle = document.getElementById("pageButtonToggle");
    const pageStatus = document.getElementById("pageButtonStatus");
    if (typeof FoxFillPrefs === "undefined") return;
    const prefs = await FoxFillPrefs.loadPrefs();
    FoxFillPrefs.applyTheme(prefs.darkMode);
    if (toggle) {
      toggle.checked = Boolean(prefs.darkMode);
      toggle.addEventListener("change", () => {
        void (async () => {
          const next = await FoxFillPrefs.savePrefs({ darkMode: toggle.checked });
          FoxFillPrefs.applyTheme(next.darkMode);
        })();
      });
    }
    if (pageToggle) {
      pageToggle.checked = Boolean(prefs.pageButton);
      pageToggle.addEventListener("change", () => {
        void (async () => {
          pageToggle.disabled = true;
          const result = await FoxFillPrefs.setPageButtonEnabled(pageToggle.checked);
          pageToggle.checked = Boolean(result.enabled);
          pageToggle.disabled = false;
          if (pageStatus) {
            pageStatus.textContent = result.ok
              ? result.enabled
                ? "On — open or reload a normal website to see the side icon, then click Fill."
                : "Off — the page icon is hidden."
              : result.error || "Couldn’t update page button.";
          }
        })();
      });
    }
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local" || !changes[FoxFillPrefs.KEY]) return;
      const next = changes[FoxFillPrefs.KEY].newValue || {};
      const dark = Boolean(next.darkMode);
      FoxFillPrefs.applyTheme(dark);
      if (toggle) toggle.checked = dark;
      if (pageToggle) pageToggle.checked = Boolean(next.pageButton);
    });
  }

  async function init() {
    bindEvents();
    populateCountrySelect();
    await initTheme();
    try {
      const peek = await FoxFillProfiles.peekEncryption();
      if (peek.encrypted) {
        try {
          profileStore = await FoxFillProfiles.loadStore(PROFILE_KEYS);
          setLockedUi(false);
        } catch (err) {
          if (err?.code === "LOCKED") {
            setLockedUi(true);
            return;
          }
          throw err;
        }
      } else {
        profileStore = await FoxFillProfiles.loadStore(PROFILE_KEYS);
        setLockedUi(false);
      }
      applyActiveProfileToUi();
      renderProfileSelect();
    } catch (err) {
      setUnlockError(err?.message || "Couldn’t load settings.");
      setLockedUi(true);
    }
  }

  void init();
})();
